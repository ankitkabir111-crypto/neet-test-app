# NEET Test App - GitHub Import Ready Repo

This repository is ready to import into GitHub.

Features:
- Offline Previous Year Questions (2016-2023) sample
- Mock test screen
- Language toggle (Hindi/English)
- Local SQLite results storage
- GitHub Actions workflow to auto-build APK on push to main
- Project policy: No China-based services

## How to import
1. Go to https://github.com/new/import
2. Drag & drop this repo (extracted folder) OR create a new repo and upload files
3. After import, push any change to `main` to trigger the workflow

## How to run locally
1. flutter pub get
2. flutter run

