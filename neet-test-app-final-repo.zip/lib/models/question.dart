class MCQQuestion {
  final String id;
  final String questionHn;
  final String questionEn;
  final List<String> options;
  final int answerIndex;
  final String explanationHn;
  final String explanationEn;
  final String difficulty;
  final String chapter;

  MCQQuestion({
    required this.id,
    required this.questionHn,
    required this.questionEn,
    required this.options,
    required this.answerIndex,
    required this.explanationHn,
    required this.explanationEn,
    required this.difficulty,
    required this.chapter,
  });

  factory MCQQuestion.fromJson(Map<String, dynamic> json) => MCQQuestion(
        id: json['id'] as String,
        questionHn: json['question_hn'] as String,
        questionEn: json['question_en'] as String,
        options: List<String>.from(json['options'] as List),
        answerIndex: json['answer_index'] as int,
        explanationHn: json['explanation_hn'] as String,
        explanationEn: json['explanation_en'] as String,
        difficulty: json['difficulty'] as String,
        chapter: json['chapter'] as String,
      );
}
