import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/lang_provider.dart';

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final lp = Provider.of<LangProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Language', style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                Radio<String>(value: 'hi', groupValue: lp.locale.languageCode, onChanged: (v) => lp.setLang(v!)),
                Text('Hindi'),
                SizedBox(width: 12),
                Radio<String>(value: 'en', groupValue: lp.locale.languageCode, onChanged: (v) => lp.setLang(v!)),
                Text('English'),
              ],
            ),
            SizedBox(height: 20),
            Text('App Policy', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('This app is free, ad-free and does not use any China-based services.'),
          ],
        ),
      ),
    );
  }
}
