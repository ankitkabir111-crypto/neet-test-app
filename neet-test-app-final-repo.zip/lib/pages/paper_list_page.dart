import 'package:flutter/material.dart';
import '../models/question.dart';
import 'test_screen.dart';

class PaperListPage extends StatelessWidget {
  final Map<String, dynamic> papersJson;
  PaperListPage({required this.papersJson});

  @override
  Widget build(BuildContext context) {
    final papers = papersJson['papers'] as List<dynamic>;
    return Scaffold(
      appBar: AppBar(title: Text('Previous Year Papers')),
      body: ListView.builder(
        itemCount: papers.length,
        itemBuilder: (context, idx) {
          final yearEntry = papers[idx] as Map<String, dynamic>;
          return ExpansionTile(
            title: Text('Year ${yearEntry['year']}'),
            children: (yearEntry['subjects'] as List<dynamic>).map((sub) {
              final subject = sub as Map<String, dynamic>;
              return ListTile(
                title: Text(subject['name']),
                onTap: () {
                  final questions = (subject['questions'] as List<dynamic>)
                      .map((q) => MCQQuestion.fromJson(q as Map<String, dynamic>))
                      .toList();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => TestScreen(questions: questions, title: '${yearEntry['year']} - ${subject['name']}')));
                },
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
