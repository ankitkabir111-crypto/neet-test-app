import 'dart:convert';
import 'package:flutter/material.dart';
import 'paper_list_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? _papersJson;

  @override
  void initState() {
    super.initState();
    _loadPapers();
  }

  Future<void> _loadPapers() async {
    final raw = await DefaultAssetBundle.of(context).loadString('assets/previous_papers.json');
    setState(() {
      _papersJson = jsonDecode(raw) as Map<String, dynamic>;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Neet Test app'), actions: [
        IconButton(icon: Icon(Icons.settings), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage())))
      ]),
      body: _papersJson == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: ListTile(
                      title: Text('Previous Year Papers'),
                      subtitle: Text('Practice NEET PYQs (2016-2023) - Offline ready'),
                      trailing: Icon(Icons.arrow_forward),
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => PaperListPage(papersJson: _papersJson!)));
                      },
                    ),
                  ),
                  SizedBox(height: 12),
                  Card(
                    child: ListTile(
                      title: Text('Mock Tests'),
                      subtitle: Text('Create and take mock tests offline'),
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Mock tests: Coming soon')));
                      },
                    ),
                  ),
                  SizedBox(height: 12),
                  Expanded(child: Center(child: Text('App is offline-first and completely free, no ads.')))
                ],
              ),
            ),
    );
  }
}
