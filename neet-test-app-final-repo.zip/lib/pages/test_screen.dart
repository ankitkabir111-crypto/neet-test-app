import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/local_db.dart';

class TestScreen extends StatefulWidget {
  final List<MCQQuestion> questions;
  final String title;
  TestScreen({required this.questions, required this.title});

  @override
  _TestScreenState createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  int _index = 0;
  int _score = 0;
  int? _selected;
  bool _showAnswer = false;

  void _submit() async {
    final q = widget.questions[_index];
    if (_selected == q.answerIndex) _score++;
    setState(() => _showAnswer = true);
  }

  void _next() async {
    setState(() {
      _selected = null;
      _showAnswer = false;
      if (_index < widget.questions.length - 1) _index++; else _showResults();
    });
  }

  void _showResults() async {
    // Save results locally
    await LocalDB.saveResult('res_' + DateTime.now().millisecondsSinceEpoch.toString(), 0, widget.title, _score, widget.questions.length);
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('Result'),
      content: Text('Score: \$_score / \${widget.questions.length}'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('OK'))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.questions[_index];
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Question \${_index + 1} / \${widget.questions.length}'),
            SizedBox(height: 12),
            Text(q.questionHn, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            ...List.generate(q.options.length, (i) {
              final opt = q.options[i];
              final correct = i == q.answerIndex;
              Color? tileColor;
              if (_showAnswer) tileColor = correct ? Colors.green[100] : (i == _selected ? Colors.red[100] : null);
              return Card(
                color: tileColor,
                child: RadioListTile<int>(
                  value: i,
                  groupValue: _selected,
                  title: Text(opt),
                  onChanged: _showAnswer ? null : (v) => setState(() => _selected = v),
                ),
              );
            }),
            Spacer(),
            if (!_showAnswer)
              ElevatedButton(onPressed: _selected == null ? null : _submit, child: Text('Submit'))
            else
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Explanation:'),
                  Text(q.explanationHn),
                  SizedBox(height: 12),
                  Row(
                    children: [
                      ElevatedButton(onPressed: _next, child: Text(_index < widget.questions.length - 1 ? 'Next' : 'Finish')),
                    ],
                  )
                ],
              )
          ],
        ),
      ),
    );
  }
}
