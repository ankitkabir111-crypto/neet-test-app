import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pages/home_page.dart';
import 'providers/lang_provider.dart';

void main() {
  runApp(NeetTestApp());
}

class NeetTestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => LangProvider(),
      child: Consumer<LangProvider>(builder: (context, lp, _) {
        return MaterialApp(
          title: 'Neet Test app',
          theme: ThemeData(primarySwatch: Colors.indigo),
          home: HomePage(),
          debugShowCheckedModeBanner: false,
          locale: lp.locale,
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: [Locale('hi'), Locale('en')],
        );
      }),
    );
  }
}
