import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LangProvider extends ChangeNotifier {
  Locale _locale = Locale('hi');

  Locale get locale => _locale;

  LangProvider() {
    _load();
  }

  void _load() async {
    final sp = await SharedPreferences.getInstance();
    final code = sp.getString('lang_code') ?? 'hi';
    _locale = Locale(code);
    notifyListeners();
  }

  void setLang(String code) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('lang_code', code);
    _locale = Locale(code);
    notifyListeners();
  }
}
