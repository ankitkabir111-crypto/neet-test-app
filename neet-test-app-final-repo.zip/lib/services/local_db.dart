import 'dart:convert';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class LocalDB {
  static Database? _db;

  static Future<Database> getDb() async {
    if (_db != null) return _db!;
    final path = await getDatabasesPath();
    final dbPath = join(path, 'neett_test.db');
    _db = await openDatabase(dbPath, version: 1, onCreate: (db, v) async {
      await db.execute('''CREATE TABLE results (id TEXT PRIMARY KEY, year INTEGER, subject TEXT, score INTEGER, total INTEGER, timestamp TEXT)''');
    });
    return _db!;
  }

  static Future<void> saveResult(String id, int year, String subject, int score, int total) async {
    final db = await getDb();
    await db.insert('results', {'id': id, 'year': year, 'subject': subject, 'score': score, 'total': total, 'timestamp': DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<Map<String, dynamic>>> getResults() async {
    final db = await getDb();
    return await db.query('results', orderBy: 'timestamp DESC');
  }
}
