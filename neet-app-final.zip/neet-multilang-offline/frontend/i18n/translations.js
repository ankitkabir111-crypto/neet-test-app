export const translations = {
  hi: { start_test: "टेस्ट शुरू करें", view_results: "पिछले परिणाम देखें" },
  en: { start_test: "Start Test", view_results: "View Results" },
  bn: { start_test: "টেস্ট শুরু করুন", view_results: "পূর্ববর্তী ফলাফল দেখুন" },
  ta: { start_test: "விருதுகள்", view_results: "முந்தைய முடிவுகள்" },
  te: { start_test: "టెస్ట్ ప్రారంభించండి", view_results: "ఫలితాలు" }
};
