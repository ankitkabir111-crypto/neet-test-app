import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App(){
  const start = async () => {
    // placeholder: navigation to home/test
    alert('App scaffold: Start Test (use full package to run)');
  };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hamara Apna NEET - Multi Language (Scaffold)</Text>
      <TouchableOpacity style={styles.button} onPress={start}>
        <Text style={styles.buttonText}>टेस्ट शुरू करें / Start Test</Text>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  container:{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'#fff',padding:20},
  title:{fontSize:20,fontWeight:'bold',marginBottom:20,textAlign:'center'},
  button:{backgroundColor:'#4CAF50',padding:12,borderRadius:8},
  buttonText:{color:'#fff',fontSize:16}
});
